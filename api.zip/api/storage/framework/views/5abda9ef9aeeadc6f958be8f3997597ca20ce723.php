<?php $__env->startSection('title', 'Auth User'); ?>

<?php $__env->startSection('navbar_ul'); ?>
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Customer</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="<?php echo e(route('customer_form_create')); ?>">Customer Form</a>
                <a class="dropdown-item" href="<?php echo e(route('customer_list')); ?>">Customer List</a>
            </div>
        </li>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Product</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="<?php echo e(route('product_form_create')); ?>">Product Form</a>
                <a class="dropdown-item" href="<?php echo e(route('product_list')); ?>">Product List</a>
            </div>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('login_form')); ?>">Login</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container vertical-separation">
        <?php echo e(Form::open(['class' => 'form-signin login-form'])); ?>

        <div class="text-center mb-4">
            <img class="mb-4" src="<?php echo e(asset('assets/img/default-avatar.png')); ?>" alt="" width="72" height="72">
            <h1 class="h3 mb-3 font-weight-normal">Login Form</h1>
        </div>

        <div class="form-label-group">
            <?php echo e(Form::email('email', old('email'), array('class' => 'form-control', 'maxlength' => 255, 'placeholder' => "Email address", 'readonly' => 'readonly'))); ?>

            <?php echo e(Form::label('email', 'Email address')); ?>

            <div id="email_error" class="alert alert-danger d-none"></div>
        </div>


        <div class="form-label-group">
            <?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' => "Password", 'readonly' => 'readonly'])); ?>

            <?php echo e(Form::label('password', 'Password')); ?>

            <div id="password_error" class="alert alert-danger d-none"></div>
        </div>


        <button type="submit" class="btn btn-lg btn-primary btn-block">Login</button>
        <p class="mt-5 mb-3 text-muted text-center">&copy; Laravel Test -2019</p>


        <?php echo e(Form::close()); ?>

    </div>


    <div role="alert" aria-live="assertive" aria-atomic="true" class="toast d-none bg-danger text-white" data-autohide="false" data-animation="false" style="position: absolute; top: 85px; right: 75px;">
        <div class="toast-header">
            <i class="fas fa-exclamation-triangle text-danger mr-1"></i>
            <strong class="mr-auto">Error</strong>
            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="toast-body">
            These credentials do not match our records.
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('view_asset_code'); ?>
    <script>

        $(document).ready(function () {
            $("input").focus(function(){
                $(this).removeAttr("readonly");
            });


            $("button[type=submit]").click(function (e) {

                e.preventDefault();
                var customer = new FormData();
                customer.append("email", $("input[name=email]").val());
                customer.append("password", $("input[name=password]").val());
                customer.append('_token', $('meta[name="csrf-token"]').attr('content'));

                $.ajax({
                    type: 'POST',
                    url: "/api/login",
                    data: customer,
                    processData: false,
                    contentType: false,
                    success: function (result, status, xhr) {
                        console.log("Respond was: ", result);
                        $("input[name=email]").removeClass('is-invalid');
                        $("#email_error").html(``);
                        $("#email_error").addClass('d-none');
                        $("input[name=password]").removeClass('is-invalid');
                        $("#password_error").html(``);
                        $("#password_error").addClass('d-none');
                        var full_url = "<?php echo e(Cache::get('full_url')); ?>";
                        var root_url = "<?php echo e(url('/')); ?>";
                        <?php echo e(Cache::forget('full_url')); ?>

                        if(full_url.replace(root_url,'') != ''){
                            window.location.href = full_url.replace(root_url,'');
                        }else{
                            window.location.href = "/";
                        }
                    },
                    error: function (result, status, xhr) {
                        console.log("There was an error: ", JSON.parse(result.responseText).errors);

                        if(JSON.parse(result.responseText).errors.email != undefined && JSON.parse(result.responseText).errors.email[0] == "These credentials do not match our records."){
                            $("input[name=email]").removeClass('is-invalid');
                            $("#email_error").html(``);
                            $("#email_error").addClass('d-none');
                            $("input[name=password]").removeClass('is-invalid');
                            $("#password_error").html(``);
                            $("#password_error").addClass('d-none');
                            $('.toast').removeClass('d-none');
                            $('.toast').toast('show');
                            setTimeout(function () {
                                $('.toast').toast('hide');
                                $('.toast').addClass('d-none');
                            }, 2000);
                        }else{
                            if (JSON.parse(result.responseText).errors.email) {
                                $("input[name=email]").addClass('is-invalid');
                                $("#email_error").html(`<p>${JSON.parse(result.responseText).errors.email}</p>`);
                                $("#email_error").removeClass('d-none');
                            } else {
                                $("input[name=email]").removeClass('is-invalid');
                                $("#email_error").html(``);
                                $("#email_error").addClass('d-none');
                            }
                            if (JSON.parse(result.responseText).errors.password) {
                                $("input[name=password]").addClass('is-invalid');
                                $("#password_error").html(`<p>${JSON.parse(result.responseText).errors.password}</p>`);
                                $("#password_error").removeClass('d-none');
                            } else {
                                $("input[name=password]").removeClass('is-invalid');
                                $("#password_error").html(``);
                                $("#password_error").addClass('d-none');
                            }
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('view_asset_code'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrador\Desktop\test-laravel\test\resources\views/auth/form.blade.php ENDPATH**/ ?>