<?php $__env->startSection('title', 'Auth User'); ?>

<?php $__env->startSection('navbar_ul'); ?>
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Customer</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="<?php echo e(route('customer_form_create')); ?>">Customer Form</a>
                <a class="dropdown-item" href="<?php echo e(route('customer_list')); ?>">Customer List</a>
            </div>
        </li>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Product</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="<?php echo e(route('product_form_create')); ?>">Product Form</a>
                <a class="dropdown-item" href="<?php echo e(route('product_list')); ?>">Product List</a>
            </div>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('login_form')); ?>">Login</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Form::open(['url' => '/api/login', 'class' => 'form-signin login-form'])); ?>

        <div class="text-center mb-4">
            <img class="mb-4" src="<?php echo e(asset('assets/img/default-avatar.png')); ?>" alt="" width="72" height="72">
            <h1 class="h3 mb-3 font-weight-normal">Login Form</h1>
        </div>

        <div class="form-label-group">
            <?php echo e(Form::email('email', old('email'), array('class' => 'form-control', 'maxlength' => 255, 'placeholder' => "Email address", "readonly" => "readonly"))); ?>

            <?php echo e(Form::label('email', 'Email address')); ?>

        </div>


        <div class="form-label-group">
            <?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' => "Password", 'readonly', "readonly" => "readonly"])); ?>

            <?php echo e(Form::label('password', 'Password')); ?>

        </div>


        <button type="submit" class="btn btn-lg btn-primary btn-block">Login</button>
        <p class="mt-5 mb-3 text-muted text-center">&copy; Laravel Test -2019</p>


        <?php echo e(Form::close()); ?>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('view_asset_code'); ?>
    <script>
        $(document).ready(function () {
            $("input").focus(function(){
                $(this).removeAttr("readonly");
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrador\Desktop\test-laravel\test\resources\views/auth/form.blade.php ENDPATH**/ ?>